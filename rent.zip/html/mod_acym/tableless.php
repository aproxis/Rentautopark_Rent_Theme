<?php

defined('_JEXEC') or die('Restricted access');
use AcyMailing\Helpers\CaptchaHelper;

$moduleParams               = new JRegistry();
$moduleParams->loadString($module->params);
$moduleIntro                    = $moduleParams->get('module-intro', ''); 
$specialTitle               = $moduleParams->get('module-specical-title','0');

?>

<div class="row">
  <?php if($specialTitle): ?>
  <div class="col-xs-12 col-sm-7 section-header">
      <?php if($module->showtitle): ?>
      <h3><span><?php echo $module->title ?></span></h3>
      <?php endif; ?>

      <?php if($moduleIntro): ?>
          <p class="container-sm module-intro"><?php echo $moduleIntro; ?></p>
      <?php endif; ?> 

      <?php if(!empty($introText)): ?>
          <p class="container-sm block-intro"><?php echo $introText; ?></p>
      <?php endif; ?> 
  </div>
  <?php endif; ?>
  <div class="col-xs-12 col-sm-3 acymailing_module<?php echo $params->get('moduleclass_sfx')?>" id="acymailing_module_<?php echo $formName; ?>">
  <?php
  $listsContent = '';
  if (!empty($visibleLists)) {
      $listsContent .= '<div class="acym_lists">';
      foreach ($visibleLists as $myListId) {
          $check = '';
          if (in_array($myListId, $checkedLists)) {
              $check = 'checked="checked"';
          }

          $listsContent .= '
              <div class="onelist">
                <input type="checkbox" class="acym_checkbox" name="subscription[]" id="acylist_'.$myListId.'_'.$formName.'" '.$check.' value="'.$myListId.'"/>
                  <label for="acylist_'.$myListId.'_'.$formName.'">'.(!empty($allLists[$myListId]->display_name) ? $allLists[$myListId]->display_name : $allLists[$myListId]->name).'</label>
              </div>';
      }
      $listsContent .= '</div>';
  }
  if ($listPosition == 'before') echo $listsContent;
  ?>

  <div class="acym_form">
      <?php
      foreach ($fields as $field) {
          $field->option = json_decode($field->option);
          $fieldDB = empty($field->option->fieldDB) ? '' : json_decode($field->option->fieldDB);
          $field->value = empty($field->value) ? '' : json_decode($field->value);
          $valuesArray = [];
          if (!empty($field->value)) {
              foreach ($field->value as $value) {
                  $valueTmp = new stdClass();
                  $valueTmp->text = $value->title;
                  $valueTmp->value = $value->value;
                  if ($value->disabled == 'y') $valueTmp->disable = true;
                  $valuesArray[$value->value] = $valueTmp;
              }
          }
          if (!empty($fieldDB) && !empty($fieldDB->value)) {
              $fromDB = $fieldClass->getValueFromDB($fieldDB);
              foreach ($fromDB as $value) {
                  $valuesArray[$value->value] = $value->title;
              }
          }
          $size = empty($field->option->size) ? '' : 'width:'.$field->option->size.'px';
          echo '<div class="onefield fieldacy'.$field->id.' acyfield_'.$field->type.'" id="field_'.$field->id.'">';
          echo $fieldClass->displayField($field, $field->default_value, $size, $valuesArray, $displayOutside, true, $identifiedUser);
          echo '</div>';

          if ($field->id == 2 && $config->get('email_confirmation')) {
              echo $fieldClass->setEmailConfirmationField($displayOutside, $size);
          }
      }

      if ($listPosition != 'before') echo $listsContent;

      if (empty($identifiedUser->id) && $config->get('captcha', 'none') !== 'none' && acym_level(ACYM_ESSENTIAL)) {
          echo '<div class="onefield fieldacycaptcha" id="field_captcha_'.$formName.'">';
          $captcha = new CaptchaHelper();
          echo $captcha->display($formName, $params->get('includejs') == 'module');
          echo '</div>';
      }

      if (!empty($termslink)) {
          echo '<div class="onefield fieldacyterms" id="field_terms_'.$formName.'">';
          echo '<label for="mailingdata_terms_'.$formName.'">';
          echo '<input id="mailingdata_terms_'.$formName.'" class="checkbox" type="checkbox" name="terms" title="'.acym_translation('ACYM_TERMS_CONDITIONS').'"/> '.$termslink;
          echo '</label>';
          echo '</div>';
      }
      ?>
  </div>

  <p class="acysubbuttons">
  <noscript>
    <div class="onefield fieldacycaptcha">
      <?php echo acym_translation('ACYM_NO_JAVASCRIPT'); ?>
    </div>
  </noscript>
  <input type="button"
      class="btn btn-primary button subbutton"
      value="<?php echo acym_translation($subscribeText, true); ?>"
      name="Submit"
      onclick="try{ return submitAcymForm('subscribe','<?php echo $formName; ?>', 'acymSubmitSubForm'); }catch(err){alert('The form could not be submitted '+err);return false;}" />
  <?php if ($unsubButton === '2' || ($unsubButton === '1' && !empty($countUnsub))) { ?>
    <span style="display: none;"></span>
    <input type="button"
        class="btn button unsubbutton"
        value="<?php echo acym_translation($unsubscribeText, true); ?>"
        name="Submit"
        onclick="try{ return submitAcymForm('unsubscribe','<?php echo $formName; ?>', 'acymSubmitSubForm'); }catch(err){alert('The form could not be submitted '+err);return false;}" />
  <?php } ?>
  </p>
  </div>
</div>

