<?php
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die;
$app = Factory::getApplication();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<jdoc:include type="head" />
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/offline.css" type="text/css" />
	<?php if ($this->direction == 'rtl') : ?>
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/offline_rtl.css" type="text/css" />
	<?php endif; ?>
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/general.css" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0;">
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,900,300,700' rel='stylesheet' type='text/css'>
</head>
<body>

<jdoc:include type="message" />
	
	<div id="frame" class="outline">		
		<?php if ($app->getCfg('offline_image')) : ?>
			<div id="offline-img"><img src="<?php echo $app->getCfg('offline_image'); ?>" alt="<?php echo htmlspecialchars($app->getCfg('sitename')); ?>" /></div>
		<?php endif; ?>
		
		<?php if ( !($app->getCfg('offline_image') && file_exists($app->getCfg('offline_image')))) : ?>
		<div id="offline-title">
			<h1><?php echo htmlspecialchars($app->getCfg('sitename')); ?></h1>
		</div>
		<?php endif; ?>

	<?php if ($app->getCfg('display_offline_message', 1) == 1 && str_replace(' ', '', $app->getCfg('offline_message')) != ''): ?>
		<div id="offline-content">
			<div class="des-offline">
				<div class="offline-des">
					<?php echo $app->getCfg('offline_message'); ?>
				</div>
			</div>

			<?php elseif ($app->getCfg('display_offline_message', 1) == 2 && str_replace(' ', '', Text::_('JOFFLINE_MESSAGE')) != ''): ?>
				<div>
					<?php echo Text::_('JOFFLINE_MESSAGE'); ?>
				</div>
			<?php  endif; ?>

			<form action="<?php echo Route::_('index.php', true); ?>" method="post" id="form-login">
			<div class="input">
					<div class="form-offline">
						<div id="form-login-username" class="form-group" >
							<label class="control-label" for="username"><?php echo Text::_('JGLOBAL_USERNAME') ?></label>
							<input class="control-input" name="username" id="username" type="text" class="inputbox" alt="<?php echo Text::_('JGLOBAL_USERNAME') ?>" size="18" />
						</div>
						<div id="form-login-password" class="form-group" >
							<label class="control-label" for="passwd"><?php echo Text::_('JGLOBAL_PASSWORD') ?></label>
							<input class="control-input" type="password" name="password" class="inputbox" size="18" alt="<?php echo Text::_('JGLOBAL_PASSWORD') ?>" id="passwd"/>
						</div>
					</div>
				<?php if (PluginHelper::isEnabled('system', 'remember')) : ?>
				<div id="form-login-remember">
					<input type="checkbox" name="remember" class="inputbox" value="yes" alt="<?php echo Text::_('JGLOBAL_REMEMBER_ME') ?>" id="remember" />
					<label for="remember"><?php echo Text::_('JGLOBAL_REMEMBER_ME') ?></label>
				</div>
				<?php  endif; ?>
				<div id="submit-buton">
					<input type="submit" name="Submit" class="button login" value="<?php echo Text::_('JLOGIN') ?>" />
				</div>
				<input type="hidden" name="option" value="com_users" />
				<input type="hidden" name="task" value="user.login" />
				<input type="hidden" name="return" value="<?php echo base64_encode(Uri::base()) ?>" />
				<?php echo HTMLHelper::_('form.token'); ?>
			</div>
			</form>
	</div>

	</div>
	
</body>
</html>
